#config file bzd_channel_bot
#ver_0.1

_TOKEN = 444858825:AAGEH88ZLJQca1rHYqdOpx3s9bK_F0LtSLk string

_FATHERid = 264315721 integer

_databaseName = fmit string
